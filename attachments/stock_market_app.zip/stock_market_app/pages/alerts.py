"""Price Alerts page."""
import streamlit as st
import pandas as pd

from config import CURRENCY_SYMBOL
from data.market_data import normalize_symbol
from services import alert_service as als
from utils.formatting import fmt_currency


def render():
    st.title("🔔 Price Alerts")

    with st.expander("➕ Create Alert", expanded=False):
        with st.form("add_alert_form", clear_on_submit=True):
            c1, c2, c3 = st.columns(3)
            symbol_raw = c1.text_input("Stock", placeholder="RELIANCE")
            target_price = c2.number_input("Target Price", min_value=0.0, step=0.5)
            condition_label = c3.selectbox("Condition", ["Price >= Target", "Price <= Target"])
            submitted = st.form_submit_button("Create Alert", use_container_width=True)

            if submitted:
                if not symbol_raw:
                    st.error("Please enter a stock symbol.")
                else:
                    try:
                        condition = ">=" if "Price >=" in condition_label else "<="
                        als.add_alert(normalize_symbol(symbol_raw), target_price, condition)
                        st.success("Alert created.")
                        st.rerun()
                    except ValueError as e:
                        st.error(str(e))

    st.divider()

    if st.button("🔄 Check Alerts Now"):
        with st.spinner("Checking alerts against live prices..."):
            triggered = als.check_alerts()
        if triggered:
            for t in triggered:
                st.balloons()
                st.success(
                    f"🎯 {t['symbol']} hit your target! Current price "
                    f"{fmt_currency(t['current_price'], CURRENCY_SYMBOL)} {t['condition']} "
                    f"{fmt_currency(t['target_price'], CURRENCY_SYMBOL)}"
                )
        else:
            st.info("No alerts triggered.")

    st.caption(
        "Notifications work fully inside the app for free. Email/Telegram push "
        "notifications are optional and stay disabled unless you add credentials "
        "to your .env file (see README)."
    )

    st.divider()
    st.subheader("Active Alerts")
    active = als.list_alerts(status="ACTIVE")
    if active:
        df = pd.DataFrame([{
            "Stock": a["symbol"], "Condition": a["condition"],
            "Target Price": fmt_currency(a["target_price"], CURRENCY_SYMBOL),
            "Created": a["created_at"].strftime("%d %b %Y %H:%M") if a["created_at"] else "N/A",
        } for a in active])
        st.dataframe(df, use_container_width=True, hide_index=True)

        del_options = {f"{a['symbol']} {a['condition']} {a['target_price']} [id={a['id']}]": a["id"] for a in active}
        to_delete = st.selectbox("Delete an active alert", ["—"] + list(del_options.keys()))
        if to_delete != "—" and st.button("Delete Selected Alert"):
            als.delete_alert(del_options[to_delete])
            st.rerun()
    else:
        st.info("No active alerts.")

    st.divider()
    st.subheader("Triggered Alerts")
    triggered = als.list_alerts(status="TRIGGERED")
    if triggered:
        df = pd.DataFrame([{
            "Stock": a["symbol"], "Condition": a["condition"],
            "Target Price": fmt_currency(a["target_price"], CURRENCY_SYMBOL),
            "Triggered": a["triggered_at"].strftime("%d %b %Y %H:%M") if a["triggered_at"] else "N/A",
        } for a in triggered])
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No triggered alerts yet.")

    st.divider()
    with st.expander("⚠️ Clear All Alerts"):
        st.warning("This will delete all alerts, active and triggered.")
        if st.button("Confirm Clear All Alerts", type="primary"):
            als.clear_alerts()
            st.success("All alerts cleared.")
            st.rerun()
