"""Dashboard page."""
import streamlit as st
import pandas as pd

from config import INDICES, MOVERS_UNIVERSE, CURRENCY_SYMBOL
from data.market_data import get_provider, is_market_open, normalize_symbol
from components.cards import index_card
from utils.formatting import fmt_change, fmt_percent


def render():
    st.title("📊 Dashboard")

    provider = get_provider()
    market_open, ist_now = is_market_open()

    status_col, time_col = st.columns([1, 2])
    with status_col:
        if market_open:
            st.success("🟢 Market Open")
        else:
            st.error("🔴 Market Closed")
    with time_col:
        st.markdown(f"**Indian Market** — {ist_now.strftime('%A, %d %B %Y, %I:%M %p')} IST")

    st.divider()
    st.subheader("Market Overview")
    cols = st.columns(len(INDICES))
    for col, (name, symbol) in zip(cols, INDICES.items()):
        with col:
            quote = provider.get_quote(symbol)
            if quote.ok:
                index_card(name, quote.price, quote.change, quote.change_pct, CURRENCY_SYMBOL)
            else:
                with st.container(border=True):
                    st.markdown(f"**{name}**")
                    st.caption("Data unavailable")

    st.divider()
    st.subheader("Market Movers")
    st.caption(
        "Scanned from a curated basket of large, liquid NSE stocks "
        "(Yahoo Finance has no free full-exchange screener)."
    )

    with st.spinner("Scanning market movers..."):
        rows = []
        for sym in MOVERS_UNIVERSE:
            q = provider.get_quote(sym)
            if q.ok and q.change_pct is not None:
                rows.append({
                    "Symbol": sym.replace(".NS", ""), "Company": q.name,
                    "Price": q.price, "Change": q.change, "Change %": q.change_pct,
                })

    if rows:
        df = pd.DataFrame(rows)
        gainers = df.sort_values("Change %", ascending=False).head(5).reset_index(drop=True)
        losers = df.sort_values("Change %", ascending=True).head(5).reset_index(drop=True)

        g_col, l_col = st.columns(2)
        with g_col:
            st.markdown("**🟢 Top Gainers**")
            st.dataframe(gainers, use_container_width=True, hide_index=True)
        with l_col:
            st.markdown("**🔴 Top Losers**")
            st.dataframe(losers, use_container_width=True, hide_index=True)
    else:
        st.info("Market movers data currently unavailable.")

    st.divider()
    st.subheader("Quick Stock Search")
    q = st.text_input("Enter a stock symbol", placeholder="RELIANCE, TCS, INFY, HDFCBANK, ICICIBANK...")
    if st.button("Search"):
        if q:
            st.session_state["selected_symbol"] = normalize_symbol(q)
            st.session_state["nav_page"] = "Stock Analysis"
            st.rerun()
