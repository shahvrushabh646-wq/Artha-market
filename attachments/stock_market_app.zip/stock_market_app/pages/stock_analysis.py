"""Stock Analysis page — the core feature of the app."""
import streamlit as st
import pandas as pd

from config import (
    CURRENCY_SYMBOL, CHART_PERIODS, DEFAULT_CHART_PERIOD, DATA_SOURCE_NOTE,
)
from data.market_data import get_provider, normalize_symbol
from data.indicators import (
    sma, rsi, rsi_interpretation, price_vs_sma, technical_summary, support_resistance,
)
from data.fundamentals import extract_fundamentals, extract_company_info
from services.valuation_service import build_valuation, build_optional_levels, build_score
from utils.calculations import pct_below_high, pct_above_low, period_high_low
from utils.formatting import fmt_currency, fmt_large_number, fmt_percent, fmt_change, fmt_number
from components.charts import candlestick_chart, volume_chart, rsi_chart, line_chart_with_sma
from components.cards import price_card, stat_card, signal_badge, verdict_badge
from components.tables import render_key_value


def render():
    st.title("🔍 Stock Analysis")

    default_symbol = st.session_state.get("selected_symbol", "RELIANCE.NS")
    raw = st.text_input(
        "Enter NSE/BSE Stock Symbol",
        value=default_symbol,
        placeholder="RELIANCE.NS, TCS.NS, INFY.NS, HDFCBANK.NS, ICICIBANK.NS",
    )
    if not raw:
        st.info("Enter a stock symbol above to begin.")
        return

    symbol = normalize_symbol(raw)
    st.session_state["selected_symbol"] = symbol
    provider = get_provider()

    with st.spinner(f"Fetching data for {symbol}..."):
        quote = provider.get_quote(symbol)

    if not quote.ok:
        st.error("Stock not found or market data unavailable.")
        return

    # ----------------------------------------------------------------- header
    st.subheader(f"{quote.name} ({symbol})")
    meta_cols = st.columns(3)
    meta_cols[0].markdown(f"**Exchange:** {quote.exchange or 'N/A'}")
    meta_cols[1].markdown(f"**Sector:** {quote.sector or 'N/A'}")
    meta_cols[2].markdown(f"**Industry:** {quote.industry or 'N/A'}")

    price_card("Current Price", quote.price, quote.change, quote.change_pct, CURRENCY_SYMBOL)
    st.caption(f"Previous Close: {fmt_currency(quote.previous_close, CURRENCY_SYMBOL)}")

    st.divider()

    # ----------------------------------------------------------- history data
    with st.spinner("Loading historical data..."):
        hist_1y = provider.get_history(symbol, "1Y")
        hist_5y = provider.get_history_years(symbol, 5)

    high_52w, high_52w_date, low_52w, low_52w_date = period_high_low(hist_1y)
    high_5y, high_5y_date, low_5y, low_5y_date = period_high_low(hist_5y)

    # ------------------------------------------------------- price statistics
    st.subheader("Price Statistics")
    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        stat_card("Current Price", fmt_currency(quote.price, CURRENCY_SYMBOL))
    with c2:
        stat_card("52 Week High", fmt_currency(high_52w, CURRENCY_SYMBOL))
    with c3:
        stat_card("52 Week Low", fmt_currency(low_52w, CURRENCY_SYMBOL))
    with c4:
        stat_card("5 Year High", fmt_currency(high_5y, CURRENCY_SYMBOL))
    with c5:
        stat_card("5 Year Low", fmt_currency(low_5y, CURRENCY_SYMBOL))

    pct_below_52h = pct_below_high(quote.price, high_52w)
    pct_above_52l = pct_above_low(quote.price, low_52w)
    pct_below_5yh = pct_below_high(quote.price, high_5y)
    pct_above_5yl = pct_above_low(quote.price, low_5y)

    d1, d2, d3, d4 = st.columns(4)
    d1.metric("% Below 52W High", fmt_percent(pct_below_52h))
    d2.metric("% Above 52W Low", fmt_percent(pct_above_52l))
    d3.metric("% Below 5Y High", fmt_percent(pct_below_5yh))
    d4.metric("% Above 5Y Low", fmt_percent(pct_above_5yl))

    if high_5y_date is not None:
        st.caption(
            f"5Y High occurred on {pd.to_datetime(high_5y_date).strftime('%d %b %Y')} · "
            f"5Y Low occurred on {pd.to_datetime(low_5y_date).strftime('%d %b %Y')}"
        )

    st.divider()

    # -------------------------------------------------------------- chart
    st.subheader("Price Chart")
    period = st.select_slider("Time Period", options=CHART_PERIODS, value=DEFAULT_CHART_PERIOD)
    with st.spinner("Loading chart..."):
        chart_hist = provider.get_history(symbol, period)

    if chart_hist.empty:
        st.warning("No historical data available for this period.")
    else:
        fig = candlestick_chart(chart_hist, title=f"{symbol} — {period}")
        if fig:
            st.plotly_chart(fig, use_container_width=True)
        vol_fig = volume_chart(chart_hist)
        if vol_fig:
            st.plotly_chart(vol_fig, use_container_width=True)

    st.divider()

    # -------------------------------------------------------- technical analysis
    st.subheader("Technical Analysis")

    close = hist_1y["Close"] if not hist_1y.empty and "Close" in hist_1y.columns else pd.Series(dtype=float)
    sma20_series = sma(close, 20)
    sma50_series = sma(close, 50)
    sma200_series = sma(close, 200) if len(close) >= 200 else pd.Series(dtype=float)
    rsi_series = rsi(close, 14)

    sma20 = round(sma20_series.iloc[-1], 2) if len(sma20_series) and not pd.isna(sma20_series.iloc[-1]) else None
    sma50 = round(sma50_series.iloc[-1], 2) if len(sma50_series) and not pd.isna(sma50_series.iloc[-1]) else None
    sma200 = round(sma200_series.iloc[-1], 2) if len(sma200_series) and not pd.isna(sma200_series.iloc[-1]) else None
    rsi_val = round(rsi_series.iloc[-1], 2) if len(rsi_series) and not pd.isna(rsi_series.iloc[-1]) else None

    t1, t2, t3, t4 = st.columns(4)
    t1.metric("RSI (14)", fmt_number(rsi_val) if rsi_val is not None else "N/A",
               rsi_interpretation(rsi_val))
    t2.metric("SMA 20", fmt_currency(sma20, CURRENCY_SYMBOL), price_vs_sma(quote.price, sma20))
    t3.metric("SMA 50", fmt_currency(sma50, CURRENCY_SYMBOL), price_vs_sma(quote.price, sma50))
    t4.metric("SMA 200", fmt_currency(sma200, CURRENCY_SYMBOL) if sma200 else "N/A",
               price_vs_sma(quote.price, sma200))

    if not hist_1y.empty:
        overlay = line_chart_with_sma(
            hist_1y, sma20_series if len(sma20_series) else None,
            sma50_series if len(sma50_series) else None,
            sma200_series if len(sma200_series) else None,
            title="Price with Moving Averages (1Y)",
        )
        if overlay:
            st.plotly_chart(overlay, use_container_width=True)
        rsi_fig = rsi_chart(hist_1y, rsi_series)
        if rsi_fig:
            st.plotly_chart(rsi_fig, use_container_width=True)

    tech_summary = technical_summary(quote.price, sma20, sma50, sma200, rsi_val)
    verdict_badge(tech_summary["verdict"])
    with st.expander("Show technical summary rules applied"):
        for rule in tech_summary["rules_applied"]:
            st.markdown(f"- {rule}")
        st.caption(
            "Rules: price above/below each SMA scores a bullish/bearish point; "
            "RSI 50-70 scores bullish, RSI < 30 or > 70 scores bearish."
        )

    sr = support_resistance(hist_1y)
    s_col, r_col = st.columns(2)
    s_col.metric("Potential Support (approx.)", fmt_currency(sr["support"], CURRENCY_SYMBOL))
    r_col.metric("Potential Resistance (approx.)", fmt_currency(sr["resistance"], CURRENCY_SYMBOL))
    st.caption("Approximate technical calculation from recent price extremes — not a guarantee.")

    st.divider()

    # -------------------------------------------------------- fundamentals
    st.subheader("Fundamental Analysis")
    with st.spinner("Loading fundamentals..."):
        info = provider.get_info(symbol)
    fundamentals = extract_fundamentals(info)

    display_fund = {}
    for k, v in fundamentals.items():
        if k == "Market Cap":
            display_fund[k] = fmt_large_number(v, CURRENCY_SYMBOL)
        elif k in ("Total Debt", "Total Cash", "Free Cash Flow", "Operating Cash Flow",
                    "Revenue", "Gross Profit", "EBITDA", "Net Income", "Enterprise Value"):
            display_fund[k] = fmt_large_number(v, CURRENCY_SYMBOL)
        elif k in ("Dividend Yield", "52 Week Change", "ROE", "ROA"):
            display_fund[k] = fmt_percent(v, already_fraction=True) if v not in (None, "N/A") else "N/A"
        elif k in ("Trailing P/E", "Forward P/E", "PEG Ratio", "Price to Book", "Beta", "Debt/Equity"):
            display_fund[k] = fmt_number(v) if v not in (None, "N/A") else "N/A"
        elif k in ("EPS", "Dividend Rate", "Book Value"):
            display_fund[k] = fmt_currency(v, CURRENCY_SYMBOL) if v not in (None, "N/A") else "N/A"
        else:
            display_fund[k] = v if v not in (None, "") else "N/A"

    render_key_value(display_fund, columns=2)
    st.caption(DATA_SOURCE_NOTE)

    st.divider()

    # -------------------------------------------------------- valuation
    st.subheader("Valuation Analysis")
    st.caption("⚠️ User-defined valuation rule — not professional investment advice.")

    valuation = build_valuation(high_5y, quote.price)
    if valuation:
        v_df = pd.DataFrame([
            {"Metric": "5 Year High", "Value": fmt_currency(valuation["high_5y"], CURRENCY_SYMBOL)},
            {"Metric": "25% Level", "Value": fmt_currency(valuation["price_75"], CURRENCY_SYMBOL)},
            {"Metric": "15% Level", "Value": fmt_currency(valuation["price_85"], CURRENCY_SYMBOL)},
            {"Metric": "5% Level", "Value": fmt_currency(valuation["price_95"], CURRENCY_SYMBOL)},
            {"Metric": "Current Price", "Value": fmt_currency(valuation["current_price"], CURRENCY_SYMBOL)},
            {"Metric": "Signal", "Value": valuation["signal"]},
        ])
        st.dataframe(v_df, use_container_width=True, hide_index=True)
        signal_badge(valuation["signal"])

        dist_75 = quote.price - valuation["price_75"]
        st.caption(f"Distance to 25% level: {fmt_change(dist_75)} {CURRENCY_SYMBOL}")
    else:
        st.info("Valuation unavailable — insufficient 5-year price history.")

    with st.expander("Optional levels (% below 5Y high) — separate from the custom rule"):
        levels = build_optional_levels(high_5y)
        if levels:
            lvl_df = pd.DataFrame(
                [{"Level": k, "Price": fmt_currency(v, CURRENCY_SYMBOL)} for k, v in levels.items()]
            )
            st.dataframe(lvl_df, use_container_width=True, hide_index=True)
        else:
            st.info("Not available — insufficient 5-year price history.")

    st.divider()

    # -------------------------------------------------------- stock score
    st.subheader("Stock Score")
    score = build_score(tech_summary, fundamentals, valuation)
    sc1, sc2, sc3, sc4 = st.columns(4)
    sc1.metric("Technical (0-40)", score["Technical Score"])
    sc2.metric("Fundamental (0-30)", score["Fundamental Score"])
    sc3.metric("Valuation (0-30)", score["Valuation Score"])
    sc4.metric("Total (0-100)", score["Total Score"])
    st.caption(
        "Transparent, rule-based score — not a mysterious AI score. "
        "Components are computed only from data that was actually available."
    )

    st.divider()

    # -------------------------------------------------------- company info
    st.subheader("Company Information")
    company = extract_company_info(info)
    render_key_value({
        "Sector": company["sector"], "Industry": company["industry"],
        "Website": company["website"], "Employees": company["employees"],
    })
    if company["summary"] not in (None, "N/A"):
        with st.expander("Business Summary"):
            st.write(company["summary"])

    st.divider()

    # -------------------------------------------------------- financial statements
    st.subheader("Financial Statements")
    with st.spinner("Loading financial statements..."):
        financials = provider.get_financials(symbol)

    freq = st.radio("Frequency", ["Annual", "Quarterly"], horizontal=True, key="fin_freq")
    suffix = "annual" if freq == "Annual" else "quarterly"

    tabs = st.tabs(["Income Statement", "Balance Sheet", "Cash Flow"])
    with tabs[0]:
        df = financials.get(f"income_{suffix}")
        st.dataframe(df, use_container_width=True) if df is not None and not df.empty else st.info("Data unavailable.")
    with tabs[1]:
        df = financials.get(f"balance_{suffix}")
        st.dataframe(df, use_container_width=True) if df is not None and not df.empty else st.info("Data unavailable.")
    with tabs[2]:
        df = financials.get(f"cashflow_{suffix}")
        st.dataframe(df, use_container_width=True) if df is not None and not df.empty else st.info("Data unavailable.")

    st.divider()

    # -------------------------------------------------------- dividends
    st.subheader("Dividends")
    dv1, dv2 = st.columns(2)
    dv1.metric("Dividend Yield", fmt_percent(fundamentals.get("Dividend Yield"), already_fraction=True)
               if fundamentals.get("Dividend Yield") not in (None, "N/A") else "N/A")
    dv2.metric("Dividend Rate", fmt_currency(fundamentals.get("Dividend Rate"), CURRENCY_SYMBOL)
               if fundamentals.get("Dividend Rate") not in (None, "N/A") else "N/A")

    with st.spinner("Loading dividend history..."):
        divs = provider.get_dividends(symbol)
    if not divs.empty:
        with st.expander("Dividend History"):
            st.dataframe(divs, use_container_width=True, hide_index=True)
    else:
        st.caption("No dividend history available.")

    st.divider()
    st.subheader("News")
    st.info("News data currently unavailable.")

    st.caption(DATA_SOURCE_NOTE)
