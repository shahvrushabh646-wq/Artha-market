"""Portfolio page."""
import datetime as dt
import streamlit as st
import pandas as pd

from config import CURRENCY_SYMBOL
from data.market_data import normalize_symbol, get_provider
from services import portfolio_service as ps
from components.charts import allocation_pie
from utils.formatting import fmt_currency, fmt_percent, fmt_change


def render():
    st.title("💼 Portfolio")

    with st.expander("➕ Add Holding", expanded=False):
        with st.form("add_holding_form", clear_on_submit=True):
            c1, c2 = st.columns(2)
            symbol_raw = c1.text_input("Stock Symbol", placeholder="RELIANCE")
            company = c2.text_input("Company (optional)")
            c3, c4 = st.columns(2)
            quantity = c3.number_input("Quantity", min_value=0.0, step=1.0)
            buy_price = c4.number_input("Buy Price", min_value=0.0, step=0.5)
            buy_date = st.date_input("Buy Date", value=dt.date.today(), max_value=dt.date.today())
            notes = st.text_area("Notes (optional)")
            submitted = st.form_submit_button("Add Holding", use_container_width=True)

            if submitted:
                if not symbol_raw:
                    st.error("Please enter a stock symbol.")
                else:
                    try:
                        symbol = normalize_symbol(symbol_raw)
                        if not company:
                            q = get_provider().get_quote(symbol)
                            company = q.name if q.ok else symbol
                        ps.add_holding(symbol, company, quantity, buy_price, buy_date, notes)
                        st.success(f"Added {symbol} to portfolio.")
                        st.rerun()
                    except ValueError as e:
                        st.error(str(e))

    st.divider()

    with st.spinner("Loading portfolio..."):
        summary = ps.get_portfolio_with_live_values()

    rows = summary["rows"]
    if not rows:
        st.info("Your portfolio is empty. Add a holding above to get started.")
        return

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Investment", fmt_currency(summary["total_invested"], CURRENCY_SYMBOL))
    c2.metric("Current Value", fmt_currency(summary["total_current_value"], CURRENCY_SYMBOL))
    c3.metric("Total P/L", fmt_currency(summary["total_pl"], CURRENCY_SYMBOL) if summary["total_pl"] is not None else "N/A",
              fmt_change(summary["total_pl_pct"]) + "%" if summary["total_pl_pct"] is not None else None)
    c4.metric("Total Return %", fmt_percent(summary["total_pl_pct"]) if summary["total_pl_pct"] is not None else "N/A")

    st.divider()
    st.subheader("Holdings")

    display_rows = []
    for r in rows:
        display_rows.append({
            "Stock": r["symbol"],
            "Qty": r["quantity"],
            "Avg Buy Price": fmt_currency(r["buy_price"], CURRENCY_SYMBOL),
            "Invested": fmt_currency(r["invested"], CURRENCY_SYMBOL),
            "Current Price": fmt_currency(r["current_price"], CURRENCY_SYMBOL) if r["current_price"] else "N/A",
            "Current Value": fmt_currency(r["current_value"], CURRENCY_SYMBOL) if r["current_value"] else "N/A",
            "P/L": fmt_currency(r["pl"], CURRENCY_SYMBOL) if r["pl"] is not None else "N/A",
            "P/L %": fmt_percent(r["pl_pct"]) if r["pl_pct"] is not None else "N/A",
        })
    st.dataframe(pd.DataFrame(display_rows), use_container_width=True, hide_index=True)

    if summary["best"]:
        st.success(f"🏆 Top performer: {summary['best']['symbol']} ({fmt_percent(summary['best']['pl_pct'])})")
    if summary["worst"]:
        st.error(f"📉 Worst performer: {summary['worst']['symbol']} ({fmt_percent(summary['worst']['pl_pct'])})")

    st.divider()
    st.subheader("Portfolio Allocation")
    labels = [r["symbol"] for r in rows]
    values = [r["invested"] for r in rows]
    fig = allocation_pie(labels, values)
    if fig:
        st.plotly_chart(fig, use_container_width=True)

    st.divider()
    st.subheader("Edit / Delete Holding")
    options = {f"{r['symbol']} (Qty {r['quantity']} @ {fmt_currency(r['buy_price'], CURRENCY_SYMBOL)}) [id={r['id']}]": r
               for r in rows}
    choice = st.selectbox("Select a holding", ["—"] + list(options.keys()))

    if choice != "—":
        holding = options[choice]
        e1, e2 = st.columns(2)
        new_qty = e1.number_input("Quantity", min_value=0.0, value=float(holding["quantity"]), key="edit_qty")
        new_price = e2.number_input("Buy Price", min_value=0.0, value=float(holding["buy_price"]), key="edit_price")
        new_notes = st.text_area("Notes", value=holding["notes"] or "", key="edit_notes")

        b1, b2 = st.columns(2)
        if b1.button("💾 Save Changes", use_container_width=True):
            try:
                ps.update_holding(holding["id"], quantity=new_qty, buy_price=new_price, notes=new_notes)
                st.success("Holding updated.")
                st.rerun()
            except ValueError as e:
                st.error(str(e))

        if b2.button("🗑️ Delete Holding", use_container_width=True, type="secondary"):
            st.session_state["confirm_delete_holding"] = holding["id"]

        if st.session_state.get("confirm_delete_holding") == holding["id"]:
            st.warning(f"Are you sure you want to delete {holding['symbol']}? This cannot be undone.")
            cc1, cc2 = st.columns(2)
            if cc1.button("Yes, delete", type="primary"):
                ps.delete_holding(holding["id"])
                del st.session_state["confirm_delete_holding"]
                st.success("Holding deleted.")
                st.rerun()
            if cc2.button("Cancel"):
                del st.session_state["confirm_delete_holding"]
                st.rerun()
