"""Settings page."""
import streamlit as st

from config import DEFAULT_CURRENCY, DEFAULT_EXCHANGE, DEFAULT_CHART_PERIOD, DISCLAIMER
from services import portfolio_service as ps
from services import watchlist_service as ws
from services import alert_service as als


def render():
    st.title("⚙️ Settings")

    st.subheader("Preferences")
    c1, c2, c3 = st.columns(3)
    c1.metric("Currency", f"{DEFAULT_CURRENCY} ₹")
    c2.metric("Default Exchange", DEFAULT_EXCHANGE)
    c3.metric("Default Chart Period", DEFAULT_CHART_PERIOD)
    st.caption("These defaults are set in config.py. Theme follows your Streamlit app theme setting.")

    st.divider()
    st.subheader("Data Management")
    st.warning("These actions permanently delete stored data and cannot be undone.")

    d1, d2, d3 = st.columns(3)

    with d1:
        if st.button("🗑️ Clear Portfolio", use_container_width=True):
            st.session_state["confirm_clear_portfolio"] = True
        if st.session_state.get("confirm_clear_portfolio"):
            st.error("Delete ALL portfolio holdings?")
            cc = st.columns(2)
            if cc[0].button("Yes, clear portfolio", key="yes_p"):
                ps.clear_portfolio()
                st.session_state["confirm_clear_portfolio"] = False
                st.success("Portfolio cleared.")
                st.rerun()
            if cc[1].button("Cancel", key="no_p"):
                st.session_state["confirm_clear_portfolio"] = False
                st.rerun()

    with d2:
        if st.button("🗑️ Clear Watchlist", use_container_width=True):
            st.session_state["confirm_clear_watchlist"] = True
        if st.session_state.get("confirm_clear_watchlist"):
            st.error("Delete ALL watchlist symbols?")
            cc = st.columns(2)
            if cc[0].button("Yes, clear watchlist", key="yes_w"):
                ws.clear_watchlist()
                st.session_state["confirm_clear_watchlist"] = False
                st.success("Watchlist cleared.")
                st.rerun()
            if cc[1].button("Cancel", key="no_w"):
                st.session_state["confirm_clear_watchlist"] = False
                st.rerun()

    with d3:
        if st.button("🗑️ Clear Alerts", use_container_width=True):
            st.session_state["confirm_clear_alerts"] = True
        if st.session_state.get("confirm_clear_alerts"):
            st.error("Delete ALL alerts?")
            cc = st.columns(2)
            if cc[0].button("Yes, clear alerts", key="yes_a"):
                als.clear_alerts()
                st.session_state["confirm_clear_alerts"] = False
                st.success("Alerts cleared.")
                st.rerun()
            if cc[1].button("Cancel", key="no_a"):
                st.session_state["confirm_clear_alerts"] = False
                st.rerun()

    st.divider()
    st.subheader("Disclaimer")
    st.info(DISCLAIMER)
