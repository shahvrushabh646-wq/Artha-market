"""Watchlist page."""
import streamlit as st
import pandas as pd

from config import CURRENCY_SYMBOL
from data.market_data import normalize_symbol
from services import watchlist_service as ws
from utils.formatting import fmt_currency, fmt_percent, fmt_number


def render():
    st.title("👁️ Watchlist")

    c1, c2 = st.columns([3, 1])
    new_symbol = c1.text_input("Add a stock symbol", placeholder="RELIANCE, TCS, INFY...")
    if c2.button("➕ Add", use_container_width=True) and new_symbol:
        ws.add_symbol(normalize_symbol(new_symbol))
        st.success(f"Added {normalize_symbol(new_symbol)} to watchlist.")
        st.rerun()

    if st.button("🔄 Refresh"):
        st.cache_data.clear()
        st.rerun()

    st.divider()

    with st.spinner("Loading watchlist..."):
        data = ws.get_watchlist_with_live_data()

    if not data:
        st.info("Your watchlist is empty. Add a stock symbol above to get started.")
        return

    for item in data:
        with st.container(border=True):
            top = st.columns([3, 1])
            top[0].markdown(f"**{item['company'] or item['symbol']}** ({item['symbol']})")
            if top[1].button("Remove", key=f"remove_{item['id']}"):
                ws.remove_symbol(item["id"])
                st.rerun()

            if not item["data_ok"]:
                st.warning("Stock not found or market data unavailable.")
                continue

            m = st.columns(4)
            m[0].metric("Price", fmt_currency(item["price"], CURRENCY_SYMBOL))
            m[1].metric("Change", fmt_currency(item["change"], CURRENCY_SYMBOL) if item["change"] is not None else "N/A",
                        f"{item['change_pct']}%" if item["change_pct"] is not None else None)
            m[2].metric("52W High", fmt_currency(item.get("high_52w"), CURRENCY_SYMBOL) if item.get("high_52w") else "N/A")
            m[3].metric("52W Low", fmt_currency(item.get("low_52w"), CURRENCY_SYMBOL) if item.get("low_52w") else "N/A")

            m2 = st.columns(4)
            m2[0].metric("RSI", fmt_number(item.get("rsi")) if item.get("rsi") else "N/A")
            m2[1].metric("SMA 20", fmt_currency(item.get("sma_20"), CURRENCY_SYMBOL) if item.get("sma_20") else "N/A")
            m2[2].metric("SMA 50", fmt_currency(item.get("sma_50"), CURRENCY_SYMBOL) if item.get("sma_50") else "N/A")
            m2[3].metric("SMA 200", fmt_currency(item.get("sma_200"), CURRENCY_SYMBOL) if item.get("sma_200") else "N/A")

            sig = item.get("signal", "N/A")
            if "BUY" in sig:
                st.success(f"Signal: {sig}")
            elif "WAIT" in sig:
                st.error(f"Signal: {sig}")
            else:
                st.info(f"Signal: {sig}")

    st.divider()
    with st.expander("⚠️ Clear Watchlist"):
        st.warning("This will remove all symbols from your watchlist.")
        if st.button("Confirm Clear Watchlist", type="primary"):
            ws.clear_watchlist()
            st.success("Watchlist cleared.")
            st.rerun()
