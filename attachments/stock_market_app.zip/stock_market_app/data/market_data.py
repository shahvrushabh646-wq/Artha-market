"""
Market data abstraction layer.

Every other module talks to THIS module, not to yfinance directly.
That means a new data provider can be added later (e.g. NSE's own API,
a paid vendor) by writing a new class with the same method signatures
and swapping which instance `get_provider()` returns.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass
from typing import Optional

import pandas as pd

# Streamlit/yfinance are runtime dependencies of the web app. Keep this
# module importable in lightweight environments (for example unit tests)
# where those optional runtime packages are not installed yet.
try:
    import streamlit as st
except ImportError:  # pragma: no cover - exercised only without app deps
    st = None

def _cache_data(**kwargs):
    if st is not None:
        return st.cache_data(**kwargs)
    def decorator(func):
        return func
    return decorator

from config import (
    QUOTE_TTL_SECONDS, HISTORY_TTL_SECONDS, FUNDAMENTALS_TTL_SECONDS,
    PERIOD_MAP, IST_OFFSET_HOURS, IST_OFFSET_MINUTES,
    MARKET_OPEN_HOUR, MARKET_OPEN_MINUTE, MARKET_CLOSE_HOUR, MARKET_CLOSE_MINUTE,
)
from utils.error_handler import log_error


@dataclass
class Quote:
    symbol: str
    name: str
    price: Optional[float]
    previous_close: Optional[float]
    change: Optional[float]
    change_pct: Optional[float]
    currency: Optional[str] = "INR"
    exchange: Optional[str] = None
    sector: Optional[str] = None
    industry: Optional[str] = None
    ok: bool = True
    error: Optional[str] = None


def normalize_symbol(raw: str) -> str:
    """Turn a bare name like 'RELIANCE' into an NSE ticker 'RELIANCE.NS'.
    Leaves already-qualified tickers (.NS / .BO / index caret symbols) untouched.
    """
    if not raw:
        return raw
    s = raw.strip().upper()
    if s.startswith("^"):
        return s
    if s.endswith(".NS") or s.endswith(".BO"):
        return s
    return f"{s}.NS"


class MarketDataProvider:
    """Abstract-ish base — swap this out for a different vendor later."""

    def get_quote(self, symbol: str) -> Quote:
        raise NotImplementedError

    def get_history(self, symbol: str, period_key: str) -> pd.DataFrame:
        raise NotImplementedError

    def get_info(self, symbol: str) -> dict:
        raise NotImplementedError


class YFinanceProvider(MarketDataProvider):
    """Yahoo Finance implementation via yfinance. Free, no API key required."""

    @_cache_data(ttl=QUOTE_TTL_SECONDS, show_spinner=False)
    def get_quote(_self, symbol: str) -> Quote:
        try:
            import yfinance as yf
            ticker = yf.Ticker(symbol)
            fast = {}
            try:
                fast = ticker.fast_info or {}
            except Exception:
                fast = {}

            price = fast.get("last_price")
            prev_close = fast.get("previous_close")
            currency = fast.get("currency", "INR")

            info = {}
            if price is None or prev_close is None:
                try:
                    info = ticker.info or {}
                except Exception:
                    info = {}
                price = price or info.get("currentPrice") or info.get("regularMarketPrice")
                prev_close = prev_close or info.get("previousClose")

            if price is None:
                # Last resort: pull the latest close from 1-day history
                hist = ticker.history(period="5d")
                if not hist.empty:
                    price = float(hist["Close"].iloc[-1])
                    if prev_close is None and len(hist) > 1:
                        prev_close = float(hist["Close"].iloc[-2])

            if price is None:
                return Quote(symbol=symbol, name=symbol, price=None,
                              previous_close=None, change=None, change_pct=None,
                              ok=False, error="No price data available")

            change = None
            change_pct = None
            if prev_close:
                change = round(price - prev_close, 2)
                change_pct = round((change / prev_close) * 100, 2) if prev_close else None

            name = info.get("longName") or info.get("shortName") or symbol
            sector = info.get("sector")
            industry = info.get("industry")
            exchange = fast.get("exchange") or info.get("exchange")

            return Quote(
                symbol=symbol, name=name, price=round(float(price), 2),
                previous_close=round(float(prev_close), 2) if prev_close else None,
                change=change, change_pct=change_pct, currency=currency,
                exchange=exchange, sector=sector, industry=industry, ok=True,
            )
        except Exception as e:
            log_error(f"get_quote({symbol})", e)
            return Quote(symbol=symbol, name=symbol, price=None, previous_close=None,
                         change=None, change_pct=None, ok=False,
                         error="Stock not found or market data unavailable.")

    @_cache_data(ttl=HISTORY_TTL_SECONDS, show_spinner=False)
    def get_history(_self, symbol: str, period_key: str) -> pd.DataFrame:
        try:
            import yfinance as yf
            yf_period, yf_interval = PERIOD_MAP.get(period_key, ("1y", "1d"))
            ticker = yf.Ticker(symbol)
            hist = ticker.history(period=yf_period, interval=yf_interval, auto_adjust=False)
            if hist is None or hist.empty:
                return pd.DataFrame()
            hist = hist.reset_index()
            date_col = "Date" if "Date" in hist.columns else "Datetime"
            hist = hist.rename(columns={date_col: "Date"})
            return hist
        except Exception as e:
            log_error(f"get_history({symbol},{period_key})", e)
            return pd.DataFrame()

    @_cache_data(ttl=HISTORY_TTL_SECONDS, show_spinner=False)
    def get_history_years(_self, symbol: str, years: int = 5) -> pd.DataFrame:
        """Dedicated helper for 5Y-high/low style calculations."""
        try:
            import yfinance as yf
            ticker = yf.Ticker(symbol)
            hist = ticker.history(period=f"{years}y", interval="1d", auto_adjust=False)
            if hist is None or hist.empty:
                return pd.DataFrame()
            hist = hist.reset_index()
            return hist
        except Exception as e:
            log_error(f"get_history_years({symbol})", e)
            return pd.DataFrame()

    @_cache_data(ttl=FUNDAMENTALS_TTL_SECONDS, show_spinner=False)
    def get_info(_self, symbol: str) -> dict:
        try:
            import yfinance as yf
            ticker = yf.Ticker(symbol)
            info = ticker.info or {}
            return info
        except Exception as e:
            log_error(f"get_info({symbol})", e)
            return {}

    @_cache_data(ttl=FUNDAMENTALS_TTL_SECONDS, show_spinner=False)
    def get_financials(_self, symbol: str):
        """Returns dict of DataFrames: income, balance, cashflow (annual + quarterly)."""
        try:
            import yfinance as yf
            ticker = yf.Ticker(symbol)
            return {
                "income_annual": _safe_df(ticker.financials),
                "income_quarterly": _safe_df(ticker.quarterly_financials),
                "balance_annual": _safe_df(ticker.balance_sheet),
                "balance_quarterly": _safe_df(ticker.quarterly_balance_sheet),
                "cashflow_annual": _safe_df(ticker.cashflow),
                "cashflow_quarterly": _safe_df(ticker.quarterly_cashflow),
            }
        except Exception as e:
            log_error(f"get_financials({symbol})", e)
            return {k: pd.DataFrame() for k in [
                "income_annual", "income_quarterly", "balance_annual",
                "balance_quarterly", "cashflow_annual", "cashflow_quarterly"]}

    @_cache_data(ttl=FUNDAMENTALS_TTL_SECONDS, show_spinner=False)
    def get_dividends(_self, symbol: str) -> pd.DataFrame:
        try:
            import yfinance as yf
            ticker = yf.Ticker(symbol)
            div = ticker.dividends
            if div is None or div.empty:
                return pd.DataFrame()
            df = div.reset_index()
            df.columns = ["Date", "Dividend"]
            return df
        except Exception as e:
            log_error(f"get_dividends({symbol})", e)
            return pd.DataFrame()


def _safe_df(df) -> pd.DataFrame:
    try:
        if df is None:
            return pd.DataFrame()
        return df
    except Exception:
        return pd.DataFrame()


def get_provider() -> MarketDataProvider:
    """Single place to swap the active market data provider."""
    return YFinanceProvider()


def is_market_open() -> tuple[bool, dt.datetime]:
    """Returns (is_open, current_ist_time). Weekend-aware. Does not account
    for exchange holidays (would require an external holiday calendar)."""
    utc_now = dt.datetime.utcnow()
    ist_now = utc_now + dt.timedelta(hours=IST_OFFSET_HOURS, minutes=IST_OFFSET_MINUTES)

    if ist_now.weekday() >= 5:  # Sat=5, Sun=6
        return False, ist_now

    open_t = ist_now.replace(hour=MARKET_OPEN_HOUR, minute=MARKET_OPEN_MINUTE, second=0, microsecond=0)
    close_t = ist_now.replace(hour=MARKET_CLOSE_HOUR, minute=MARKET_CLOSE_MINUTE, second=0, microsecond=0)
    return open_t <= ist_now <= close_t, ist_now
