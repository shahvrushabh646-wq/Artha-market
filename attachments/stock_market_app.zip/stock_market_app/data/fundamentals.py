"""
Fundamental-data extraction from the raw yfinance `.info` dict.

Never invents numbers: any missing key becomes the string "N/A" so the UI
can render it plainly rather than crashing or showing a fake value.
"""
from __future__ import annotations

NA = "N/A"


def _get(info: dict, *keys, default=NA):
    for k in keys:
        v = info.get(k)
        if v is not None:
            return v
    return default


def extract_fundamentals(info: dict) -> dict:
    """Returns a flat dict of label -> value (or 'N/A') for display."""
    if not info:
        return {k: NA for k in FUNDAMENTAL_LABELS}

    return {
        "Market Cap": _get(info, "marketCap"),
        "Enterprise Value": _get(info, "enterpriseValue"),
        "Trailing P/E": _get(info, "trailingPE"),
        "Forward P/E": _get(info, "forwardPE"),
        "PEG Ratio": _get(info, "pegRatio", "trailingPegRatio"),
        "Price to Book": _get(info, "priceToBook"),
        "EPS": _get(info, "trailingEps"),
        "Dividend Yield": _get(info, "dividendYield"),
        "Dividend Rate": _get(info, "dividendRate"),
        "Beta": _get(info, "beta"),
        "52 Week Change": _get(info, "52WeekChange"),
        "Book Value": _get(info, "bookValue"),
        "ROE": _get(info, "returnOnEquity"),
        "ROA": _get(info, "returnOnAssets"),
        "Total Debt": _get(info, "totalDebt"),
        "Total Cash": _get(info, "totalCash"),
        "Debt/Equity": _get(info, "debtToEquity"),
        "Free Cash Flow": _get(info, "freeCashflow"),
        "Operating Cash Flow": _get(info, "operatingCashflow"),
        "Revenue": _get(info, "totalRevenue"),
        "Gross Profit": _get(info, "grossProfits"),
        "EBITDA": _get(info, "ebitda"),
        "Net Income": _get(info, "netIncomeToCommon"),
    }


FUNDAMENTAL_LABELS = [
    "Market Cap", "Enterprise Value", "Trailing P/E", "Forward P/E",
    "PEG Ratio", "Price to Book", "EPS", "Dividend Yield", "Dividend Rate",
    "Beta", "52 Week Change", "Book Value", "ROE", "ROA", "Total Debt",
    "Total Cash", "Debt/Equity", "Free Cash Flow", "Operating Cash Flow",
    "Revenue", "Gross Profit", "EBITDA", "Net Income",
]


def extract_company_info(info: dict) -> dict:
    if not info:
        return {"name": NA, "sector": NA, "industry": NA, "website": NA,
                "summary": NA, "employees": NA}
    return {
        "name": _get(info, "longName", "shortName"),
        "sector": _get(info, "sector"),
        "industry": _get(info, "industry"),
        "website": _get(info, "website"),
        "summary": _get(info, "longBusinessSummary"),
        "employees": _get(info, "fullTimeEmployees"),
    }
