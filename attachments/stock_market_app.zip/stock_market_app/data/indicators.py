"""Technical indicator calculations. Pure functions over pandas Series."""
from __future__ import annotations
import pandas as pd
import numpy as np


def sma(series: pd.Series, window: int) -> pd.Series:
    """Simple moving average. Returns NaN where insufficient history exists."""
    if series is None or len(series) < 1:
        return pd.Series(dtype=float)
    return series.rolling(window=window, min_periods=window).mean()


def rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Standard Wilder's RSI (14-period default)."""
    if series is None or len(series) < period + 1:
        return pd.Series(dtype=float)

    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)

    avg_gain = gain.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period, adjust=False).mean()

    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi_series = 100 - (100 / (1 + rs))
    rsi_series = rsi_series.where(avg_loss != 0, 100.0)  # no losses => RSI 100
    return rsi_series


def rsi_interpretation(value: float) -> str:
    if value is None or pd.isna(value):
        return "N/A"
    if value < 30:
        return "Oversold"
    if value < 50:
        return "Weak / Bearish"
    if value <= 70:
        return "Neutral / Bullish"
    return "Overbought"


def price_vs_sma(price: float, sma_value: float) -> str:
    if price is None or sma_value is None or pd.isna(sma_value):
        return "N/A"
    return "Above" if price > sma_value else ("Below" if price < sma_value else "At")


def technical_summary(price: float, sma20: float, sma50: float, sma200: float,
                       rsi_value: float) -> dict:
    """Transparent rule-based Bullish / Neutral / Bearish call.

    Rules (each contributes +1 bullish or +1 bearish point, shown in UI):
      - Price above SMA20  -> bullish point
      - Price above SMA50  -> bullish point
      - Price above SMA200 -> bullish point
      - RSI between 50-70  -> bullish point ; RSI < 30 -> bearish point (oversold pressure)
      - RSI > 70 -> bearish point (overbought risk)
    """
    bullish_points = 0
    bearish_points = 0
    rules_applied = []

    for label, sma_val in [("SMA 20", sma20), ("SMA 50", sma50), ("SMA 200", sma200)]:
        rel = price_vs_sma(price, sma_val)
        if rel == "Above":
            bullish_points += 1
            rules_applied.append(f"Price above {label} (+1 bullish)")
        elif rel == "Below":
            bearish_points += 1
            rules_applied.append(f"Price below {label} (+1 bearish)")

    if rsi_value is not None and not pd.isna(rsi_value):
        if 50 <= rsi_value <= 70:
            bullish_points += 1
            rules_applied.append("RSI in 50-70 bullish zone (+1 bullish)")
        elif rsi_value < 30:
            bearish_points += 1
            rules_applied.append("RSI < 30 oversold (+1 bearish signal)")
        elif rsi_value > 70:
            bearish_points += 1
            rules_applied.append("RSI > 70 overbought (+1 bearish signal)")

    if bullish_points > bearish_points:
        verdict = "🟢 Bullish"
    elif bearish_points > bullish_points:
        verdict = "🔴 Bearish"
    else:
        verdict = "🟡 Neutral"

    return {
        "verdict": verdict,
        "bullish_points": bullish_points,
        "bearish_points": bearish_points,
        "rules_applied": rules_applied,
    }


def support_resistance(history: pd.DataFrame, lookback: int = 60) -> dict:
    """Very simple approximate support/resistance from recent rolling extremes.
    Clearly an approximation — not a professional pivot-point model."""
    if history is None or history.empty or "Close" not in history.columns:
        return {"support": None, "resistance": None}
    recent = history.tail(lookback)
    support = float(recent["Low"].min()) if "Low" in recent.columns else float(recent["Close"].min())
    resistance = float(recent["High"].max()) if "High" in recent.columns else float(recent["Close"].max())
    return {"support": round(support, 2), "resistance": round(resistance, 2)}
