# Indian Stock Market Dashboard

NSE • BSE • Portfolio • Technical Analysis • Fundamentals

A local, free, no-API-key-required dashboard for tracking Indian stocks,
built with Streamlit and free Yahoo Finance data (`yfinance`).

## Features

- **Dashboard** — NIFTY 50 / SENSEX / NIFTY BANK / NIFTY IT / NIFTY MIDCAP
  overview, live market open/closed status, top gainers/losers from a
  curated large-cap NSE basket, quick stock search
- **Stock Analysis** — 52-week & 5-year high/low stats, interactive
  candlestick charts (1D–MAX), RSI(14) + SMA 20/50/200 with a transparent
  bullish/bearish verdict, full fundamentals, financial statements
  (income/balance/cash flow, annual & quarterly), dividends, a
  **user-defined valuation rule**, and a transparent 0–100 stock score
- **Portfolio** — add/edit/delete holdings, live P/L, allocation chart,
  best/worst performer, stored in local SQLite (survives restarts)
- **Watchlist** — live price, 52W range, RSI, SMAs, and the custom
  BUY/WAIT signal for every symbol you're tracking
- **Alerts** — price ≥ / ≤ target alerts, checked on demand, no paid
  notification service required
- **Settings** — clear portfolio/watchlist/alerts (with confirmation)

## Requirements

- Python 3.11+ (a Python 3.11–3.13 virtual environment is recommended)
- Internet access (Yahoo Finance data is fetched live — no data is bundled
  or faked)

No API key is required for any core feature. Optional integrations
(Telegram/email alert push notifications) are described below and stay
fully disabled until you provide credentials.

## Installation

### 1. Get the code

Place the `stock_market_app/` folder wherever you like, then open a
terminal inside it.

### 2. Create a virtual environment

**Windows (PowerShell):**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
```

**Mac / Linux:**
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the application

```bash
streamlit run app.py
```

Streamlit will print a local URL (usually `http://localhost:8501`) —
open it in your browser. It also works fine on your phone's browser if
you're on the same network and use your machine's local IP instead of
`localhost`.

## How to use it

### Searching stocks
Use the sidebar "Quick Stock Search" or the Dashboard search box. Type a
bare name like `RELIANCE` and it's automatically normalized to
`RELIANCE.NS`. You can also type a fully-qualified ticker directly, e.g.
`TCS.NS`, `INFY.NS`, or a BSE ticker like `500325.BO`.

### Adding a portfolio holding
Go to **Portfolio → ➕ Add Holding**, enter the symbol, quantity, buy
price, and buy date. Quantity and buy price must both be greater than
zero — the form validates this before saving. Holdings are stored in a
local SQLite file (`stock_app.db`) and persist across restarts.

### Adding a watchlist symbol
Go to **Watchlist**, type a symbol, and click **Add**. Each row shows
live price, 52-week range, RSI, SMA 20/50/200, and the custom BUY/WAIT
signal. Use **Refresh** to force-refetch live data.

### Creating a price alert
Go to **Alerts → ➕ Create Alert**, choose a symbol, a target price, and
a condition (`Price >= Target` or `Price <= Target`). Click
**🔄 Check Alerts Now** to evaluate all active alerts against current
prices — any that cross their target move to "Triggered".

### How the valuation rule works

This is a **user-defined rule**, not professional investment advice.
Given a stock's 5-year high price:

```python
price_75 = round(high_5y * 0.25, 2)   # 25% of the 5-year high
price_85 = round(high_5y * 0.15, 2)   # 15% of the 5-year high
price_95 = round(high_5y * 0.05, 2)   # 5% of the 5-year high

if current_price <= price_75:
    signal = "🟢 BUY"
else:
    signal = "🔴 WAIT"
```

The Stock Analysis page and Watchlist both display this exact
calculation and the resulting signal. A separate, clearly-labeled
"optional levels" table also shows straightforward percentage-below-high
levels (10/20/25/30/50% below the 5-year high) — don't confuse these
with the custom rule's 25%/15%/5%-of-high values.

## Ticker format reference

| Market | Format          | Example        |
|--------|-----------------|----------------|
| NSE    | `SYMBOL.NS`     | `RELIANCE.NS`  |
| BSE    | `SYMBOL.BO`     | `500325.BO`    |
| Index  | `^SYMBOL`       | `^NSEI` (NIFTY 50) |

## Optional integrations (disabled by default)

Create a `.env` file (see `.gitignore` — it's never committed) in the
project root to enable optional features. Every feature works fine
without this file.

```
# Optional: enables a future news integration if you wire one in
NEWS_API_KEY=

# Optional: enables Telegram alert push notifications
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=

# Optional: enables email alert notifications
SMTP_HOST=
```

## Known limitations of `yfinance` / free data

- Yahoo Finance has **no free full-exchange screener**, so "Top
  Gainers/Losers" scans a curated basket of ~30 liquid large-cap NSE
  stocks rather than the entire exchange — this is stated in the UI.
- Fundamentals and financial-statement coverage varies by company; any
  field Yahoo doesn't provide is shown as `N/A`, never a fabricated
  number.
- Data can be delayed by Yahoo Finance itself, independent of this app.
- Intraday (`1D`) data availability depends on Yahoo Finance's short-term
  data retention window.
- The market-open/closed indicator is based on standard NSE/BSE trading
  hours (9:15 AM–3:30 PM IST, Mon–Fri) and does **not** account for
  exchange holidays.

## Running the tests

```bash
python -m unittest tests.test_calculations -v
```

or, with `pytest` installed:

```bash
pytest tests/ -v
```

Tests cover: percentage calculations, 52-week/5-year high-low extraction,
the custom valuation rule (including its exact BUY/WAIT boundary),
optional valuation levels, the transparent stock score, currency/percent
formatting, and invalid-input rejection (zero/negative quantity or price).

## Project structure

```
stock_market_app/
├── app.py                    # Streamlit entry point
├── config.py                 # All app-wide settings & constants
├── requirements.txt
├── README.md
├── .gitignore
│
├── database/
│   ├── db.py                 # SQLAlchemy engine/session
│   └── models.py             # Portfolio, Watchlist, Alert, Settings tables
│
├── data/
│   ├── market_data.py        # yfinance abstraction layer (swap providers here)
│   ├── indicators.py         # RSI, SMA, technical summary, support/resistance
│   └── fundamentals.py       # Safe fundamentals/company-info extraction
│
├── services/
│   ├── portfolio_service.py  # Portfolio CRUD + live P/L
│   ├── watchlist_service.py  # Watchlist CRUD + live technicals
│   ├── alert_service.py      # Alert CRUD + evaluation
│   └── valuation_service.py  # Custom valuation rule + stock score
│
├── components/
│   ├── charts.py             # Plotly chart builders
│   ├── cards.py               # Metric card helpers
│   ├── tables.py              # Mobile-friendly table helpers
│   └── sidebar.py             # Navigation + quick search
│
├── pages/
│   ├── dashboard.py
│   ├── stock_analysis.py
│   ├── portfolio.py
│   ├── watchlist.py
│   ├── alerts.py
│   └── settings.py
│
├── utils/
│   ├── formatting.py          # Currency/percent/number display formatting
│   ├── calculations.py        # Core financial math (unit tested)
│   └── error_handler.py       # Logging + friendly error messages
│
└── tests/
    └── test_calculations.py
```

## Disclaimer

This application is for educational and informational purposes only. It
is not financial, investment, tax or legal advice. Market data may be
delayed or inaccurate. Users should independently verify information
before making investment decisions.
