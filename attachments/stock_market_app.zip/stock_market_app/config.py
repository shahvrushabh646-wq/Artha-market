"""
Central configuration for the Indian Stock Market Dashboard.
No secrets/API keys live here — those come from environment variables (.env)
or Streamlit secrets, and every optional-feature flag defaults to OFF/None
so the app runs fully without any keys.
"""
import os
from dotenv import load_dotenv

load_dotenv()

APP_NAME = "Indian Stock Market Dashboard"
APP_SUBTITLE = "NSE • BSE • Portfolio • Technical Analysis • Fundamentals"

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stock_app.db")
DATABASE_URL = f"sqlite:///{DB_PATH}"

# ---------------------------------------------------------------------------
# Market data
# ---------------------------------------------------------------------------
DEFAULT_CURRENCY = "INR"
CURRENCY_SYMBOL = "₹"
DEFAULT_EXCHANGE = "NSE"
DEFAULT_CHART_PERIOD = "1Y"

# Index symbols on Yahoo Finance for Indian markets
INDICES = {
    "NIFTY 50": "^NSEI",
    "SENSEX": "^BSESN",
    "NIFTY BANK": "^NSEBANK",
    "NIFTY IT": "^CNXIT",
    "NIFTY MIDCAP": "^NSEMDCP50",
}

# A small curated universe used for "Top Gainers / Top Losers" scanning.
# (Yahoo Finance has no free NSE-wide screener endpoint, so we scan a
# representative basket of large/liquid NSE stocks rather than the whole
# exchange. This is clearly labeled in the UI.)
MOVERS_UNIVERSE = [
    "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS", "ICICIBANK.NS", "INFY.NS",
    "HINDUNILVR.NS", "ITC.NS", "SBIN.NS", "BHARTIARTL.NS", "LT.NS",
    "KOTAKBANK.NS", "AXISBANK.NS", "BAJFINANCE.NS", "ASIANPAINT.NS",
    "MARUTI.NS", "SUNPHARMA.NS", "TITAN.NS", "WIPRO.NS", "ULTRACEMCO.NS",
    "NESTLEIND.NS", "TATAMOTORS.NS", "TATASTEEL.NS", "ADANIENT.NS",
    "POWERGRID.NS", "NTPC.NS", "HCLTECH.NS", "ONGC.NS", "JSWSTEEL.NS",
    "M&M.NS", "TECHM.NS",
]

CHART_PERIODS = ["1D", "1W", "1M", "3M", "6M", "1Y", "3Y", "5Y", "MAX"]

# Mapping UI period -> (yfinance period, yfinance interval)
PERIOD_MAP = {
    "1D": ("1d", "5m"),
    "1W": ("5d", "15m"),
    "1M": ("1mo", "1d"),
    "3M": ("3mo", "1d"),
    "6M": ("6mo", "1d"),
    "1Y": ("1y", "1d"),
    "3Y": ("3y", "1wk"),
    "5Y": ("5y", "1wk"),
    "MAX": ("max", "1mo"),
}

# ---------------------------------------------------------------------------
# Indian market trading hours (IST) — used to compute live market status
# ---------------------------------------------------------------------------
MARKET_OPEN_HOUR = 9
MARKET_OPEN_MINUTE = 15
MARKET_CLOSE_HOUR = 15
MARKET_CLOSE_MINUTE = 30
IST_OFFSET_HOURS = 5
IST_OFFSET_MINUTES = 30

# ---------------------------------------------------------------------------
# Caching
# ---------------------------------------------------------------------------
QUOTE_TTL_SECONDS = 60          # live-ish price data
HISTORY_TTL_SECONDS = 60 * 15   # historical OHLC
FUNDAMENTALS_TTL_SECONDS = 60 * 60  # fundamentals change slowly

# ---------------------------------------------------------------------------
# Optional features (disabled unless the relevant credential is set)
# ---------------------------------------------------------------------------
NEWS_API_KEY = os.getenv("NEWS_API_KEY")  # optional, feature auto-disables if absent
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
SMTP_HOST = os.getenv("SMTP_HOST")

DISCLAIMER = (
    "This application is for educational and informational purposes only. "
    "It is not financial, investment, tax or legal advice. Market data may be "
    "delayed or inaccurate. Users should independently verify information "
    "before making investment decisions."
)

DATA_SOURCE_NOTE = "Data source: Yahoo Finance / yfinance. Market data may be delayed."
