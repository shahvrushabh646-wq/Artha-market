"""Business logic for portfolio holdings: CRUD + live P/L calculations."""
from __future__ import annotations
import datetime as dt

from database.db import get_session
from database.models import Portfolio
from data.market_data import get_provider


def add_holding(symbol: str, company: str, quantity: float, buy_price: float,
                 buy_date: dt.date, notes: str = ""):
    if quantity is None or quantity <= 0:
        raise ValueError("Quantity must be greater than 0")
    if buy_price is None or buy_price <= 0:
        raise ValueError("Buy price must be greater than 0")

    with get_session() as session:
        holding = Portfolio(
            symbol=symbol.strip().upper(), company=company, quantity=quantity,
            buy_price=buy_price, buy_date=buy_date, notes=notes,
        )
        session.add(holding)
        session.flush()
        return holding.id


def update_holding(holding_id: int, **fields):
    if "quantity" in fields and fields["quantity"] is not None and fields["quantity"] <= 0:
        raise ValueError("Quantity must be greater than 0")
    if "buy_price" in fields and fields["buy_price"] is not None and fields["buy_price"] <= 0:
        raise ValueError("Buy price must be greater than 0")

    with get_session() as session:
        holding = session.query(Portfolio).filter(Portfolio.id == holding_id).first()
        if not holding:
            raise ValueError("Holding not found")
        for k, v in fields.items():
            if v is not None and hasattr(holding, k):
                setattr(holding, k, v)


def delete_holding(holding_id: int):
    with get_session() as session:
        holding = session.query(Portfolio).filter(Portfolio.id == holding_id).first()
        if holding:
            session.delete(holding)


def list_holdings() -> list[dict]:
    with get_session() as session:
        rows = session.query(Portfolio).order_by(Portfolio.created_at.desc()).all()
        return [
            {
                "id": r.id, "symbol": r.symbol, "company": r.company,
                "quantity": r.quantity, "buy_price": r.buy_price,
                "buy_date": r.buy_date, "notes": r.notes,
            }
            for r in rows
        ]


def clear_portfolio():
    with get_session() as session:
        session.query(Portfolio).delete()


def get_portfolio_with_live_values() -> dict:
    """Returns full portfolio summary with live prices merged in.
    Never crashes if a quote is unavailable — that row just shows N/A P/L."""
    holdings = list_holdings()
    provider = get_provider()

    rows = []
    total_invested = 0.0
    total_current = 0.0

    for h in holdings:
        quote = provider.get_quote(h["symbol"])
        invested = h["quantity"] * h["buy_price"]
        total_invested += invested

        if quote.ok and quote.price is not None:
            current_value = h["quantity"] * quote.price
            pl = current_value - invested
            pl_pct = (pl / invested) * 100 if invested else None
            total_current += current_value
        else:
            current_value = None
            pl = None
            pl_pct = None

        rows.append({
            **h,
            "current_price": quote.price,
            "invested": round(invested, 2),
            "current_value": round(current_value, 2) if current_value is not None else None,
            "pl": round(pl, 2) if pl is not None else None,
            "pl_pct": round(pl_pct, 2) if pl_pct is not None else None,
            "data_ok": quote.ok,
        })

    total_pl = total_current - total_invested if total_current else None
    total_pl_pct = (total_pl / total_invested * 100) if (total_pl is not None and total_invested) else None

    best = max((r for r in rows if r["pl_pct"] is not None), key=lambda r: r["pl_pct"], default=None)
    worst = min((r for r in rows if r["pl_pct"] is not None), key=lambda r: r["pl_pct"], default=None)

    return {
        "rows": rows,
        "total_invested": round(total_invested, 2),
        "total_current_value": round(total_current, 2) if rows else 0.0,
        "total_pl": round(total_pl, 2) if total_pl is not None else None,
        "total_pl_pct": round(total_pl_pct, 2) if total_pl_pct is not None else None,
        "best": best,
        "worst": worst,
    }
