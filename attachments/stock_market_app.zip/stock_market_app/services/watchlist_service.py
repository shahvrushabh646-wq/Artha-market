"""Business logic for the watchlist."""
from __future__ import annotations
import pandas as pd

from database.db import get_session
from database.models import Watchlist
from data.market_data import get_provider
from data.indicators import sma, rsi
from utils.calculations import period_high_low, custom_valuation


def add_symbol(symbol: str):
    symbol = symbol.strip().upper()
    with get_session() as session:
        exists = session.query(Watchlist).filter(Watchlist.symbol == symbol).first()
        if exists:
            return exists.id
        w = Watchlist(symbol=symbol)
        session.add(w)
        session.flush()
        return w.id


def remove_symbol(watchlist_id: int):
    with get_session() as session:
        w = session.query(Watchlist).filter(Watchlist.id == watchlist_id).first()
        if w:
            session.delete(w)


def list_symbols() -> list[dict]:
    with get_session() as session:
        rows = session.query(Watchlist).order_by(Watchlist.created_at.desc()).all()
        return [{"id": r.id, "symbol": r.symbol} for r in rows]


def clear_watchlist():
    with get_session() as session:
        session.query(Watchlist).delete()


def get_watchlist_with_live_data() -> list[dict]:
    provider = get_provider()
    items = list_symbols()
    results = []

    for item in items:
        symbol = item["symbol"]
        quote = provider.get_quote(symbol)
        hist_1y = provider.get_history(symbol, "1Y")
        hist_5y = provider.get_history_years(symbol, 5)

        row = {
            "id": item["id"], "symbol": symbol, "company": quote.name,
            "price": quote.price, "change": quote.change, "change_pct": quote.change_pct,
            "data_ok": quote.ok,
        }

        if not hist_1y.empty and "Close" in hist_1y.columns:
            high_52w, _, low_52w, _ = period_high_low(hist_1y)
            row["high_52w"] = high_52w
            row["low_52w"] = low_52w

            close = hist_1y["Close"]
            row["sma_20"] = round(sma(close, 20).iloc[-1], 2) if len(close) >= 20 and not pd.isna(sma(close, 20).iloc[-1]) else None
            row["sma_50"] = round(sma(close, 50).iloc[-1], 2) if len(close) >= 50 and not pd.isna(sma(close, 50).iloc[-1]) else None
            rsi_series = rsi(close, 14)
            row["rsi"] = round(rsi_series.iloc[-1], 2) if len(rsi_series) and not pd.isna(rsi_series.iloc[-1]) else None
        else:
            row.update({"high_52w": None, "low_52w": None, "sma_20": None, "sma_50": None, "rsi": None})

        if not hist_5y.empty:
            high_5y, _, _, _ = period_high_low(hist_5y)
            row["sma_200"] = None
            if not hist_1y.empty and len(hist_1y) >= 200:
                sma200_series = sma(hist_1y["Close"], 200)
                row["sma_200"] = round(sma200_series.iloc[-1], 2) if not pd.isna(sma200_series.iloc[-1]) else None
            if quote.price is not None:
                val = custom_valuation(high_5y, quote.price)
                row["signal"] = val["signal"] if val else "N/A"
            else:
                row["signal"] = "N/A"
        else:
            row["sma_200"] = None
            row["signal"] = "N/A"

        results.append(row)

    return results
