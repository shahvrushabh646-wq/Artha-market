"""Business logic for price alerts. Fully local (SQLite) — no paid
notification service required. Email/Telegram hooks stay disabled unless
credentials are present in the environment (see config.py)."""
from __future__ import annotations
import datetime as dt

from database.db import get_session
from database.models import Alert
from data.market_data import get_provider
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, SMTP_HOST


def add_alert(symbol: str, target_price: float, condition: str):
    if condition not in (">=", "<="):
        raise ValueError("Condition must be '>=' or '<='")
    if target_price is None or target_price <= 0:
        raise ValueError("Target price must be greater than 0")

    with get_session() as session:
        a = Alert(symbol=symbol.strip().upper(), target_price=target_price,
                   condition=condition, status="ACTIVE")
        session.add(a)
        session.flush()
        return a.id


def delete_alert(alert_id: int):
    with get_session() as session:
        a = session.query(Alert).filter(Alert.id == alert_id).first()
        if a:
            session.delete(a)


def list_alerts(status: str | None = None) -> list[dict]:
    with get_session() as session:
        q = session.query(Alert)
        if status:
            q = q.filter(Alert.status == status)
        rows = q.order_by(Alert.created_at.desc()).all()
        return [
            {
                "id": r.id, "symbol": r.symbol, "target_price": r.target_price,
                "condition": r.condition, "status": r.status,
                "created_at": r.created_at, "triggered_at": r.triggered_at,
            }
            for r in rows
        ]


def clear_alerts():
    with get_session() as session:
        session.query(Alert).delete()


def check_alerts() -> list[dict]:
    """Evaluates all ACTIVE alerts against live prices, marks any that have
    crossed their target as TRIGGERED, and returns the list of newly
    triggered alerts (for display / optional notification)."""
    provider = get_provider()
    newly_triggered = []

    with get_session() as session:
        active = session.query(Alert).filter(Alert.status == "ACTIVE").all()
        for a in active:
            quote = provider.get_quote(a.symbol)
            if not quote.ok or quote.price is None:
                continue
            crossed = (
                (a.condition == ">=" and quote.price >= a.target_price) or
                (a.condition == "<=" and quote.price <= a.target_price)
            )
            if crossed:
                a.status = "TRIGGERED"
                a.triggered_at = dt.datetime.utcnow()
                newly_triggered.append({
                    "symbol": a.symbol, "target_price": a.target_price,
                    "condition": a.condition, "current_price": quote.price,
                })

    _maybe_notify(newly_triggered)
    return newly_triggered


def _maybe_notify(triggered: list[dict]):
    """Optional Telegram/email notification — no-op unless credentials exist."""
    if not triggered:
        return
    if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
        # Intentionally left as a stub: enabling real network notifications
        # requires the user to supply working credentials in .env.
        pass
    if SMTP_HOST:
        pass
