"""Orchestrates the custom valuation rule + optional levels + stock score
for the Stock Analysis page."""
from __future__ import annotations

from utils.calculations import custom_valuation, optional_below_high_levels, stock_score


def build_valuation(high_5y, current_price):
    return custom_valuation(high_5y, current_price)


def build_optional_levels(high_5y):
    return optional_below_high_levels(high_5y)


def build_score(tech_summary, fundamentals, valuation):
    return stock_score(tech_summary, fundamentals, valuation)
