"""
Indian Stock Market Dashboard — main entry point.

Run with:
    streamlit run app.py
"""
import streamlit as st

from config import APP_NAME, APP_SUBTITLE, DISCLAIMER, DATA_SOURCE_NOTE
from database.db import init_db
from components.sidebar import render_sidebar
from pages import dashboard, stock_analysis, portfolio, watchlist, alerts, settings

st.set_page_config(
    page_title=APP_NAME,
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Create SQLite tables on first run — safe to call every run.
init_db()

if "nav_page" not in st.session_state:
    st.session_state["nav_page"] = "Dashboard"

page = render_sidebar()


def render_about():
    st.title("ℹ️ About")
    st.markdown(f"### {APP_NAME}")
    st.caption(APP_SUBTITLE)
    st.markdown(
        """
This dashboard tracks NSE & BSE listed stocks using free, live Yahoo Finance
data via the `yfinance` library — no paid API keys required.

**Features**
- Live market overview (NIFTY 50, SENSEX, sector indices)
- Stock search with 52-week and 5-year statistics
- Interactive candlestick charts across multiple time periods
- Technical analysis: RSI(14), SMA 20/50/200, transparent bullish/bearish summary
- Fundamentals: valuation ratios, profitability, balance sheet metrics
- A user-defined valuation rule (25% / 15% / 5% of 5-year high) — clearly
  labeled as a personal rule, not investment advice
- Transparent 0-100 stock score (Technical + Fundamental + Valuation)
- Portfolio tracking with live P/L, stored locally in SQLite
- Watchlist with live technicals and the custom BUY/WAIT signal
- Price alerts, checked on demand against live prices
        """
    )
    st.divider()
    st.subheader("Disclaimer")
    st.warning(DISCLAIMER)
    st.caption(DATA_SOURCE_NOTE)


PAGE_RENDERERS = {
    "Dashboard": dashboard.render,
    "Stock Analysis": stock_analysis.render,
    "Portfolio": portfolio.render,
    "Watchlist": watchlist.render,
    "Alerts": alerts.render,
    "Settings": settings.render,
    "About": render_about,
}

try:
    PAGE_RENDERERS.get(page, dashboard.render)()
except Exception as e:
    from utils.error_handler import log_error
    log_error(f"render page {page}", e)
    st.error("Something went wrong loading this page. Please try refreshing.")
