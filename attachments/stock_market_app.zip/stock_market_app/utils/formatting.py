"""Display-formatting helpers. All functions are crash-safe on None/'N/A'."""
from __future__ import annotations


def fmt_currency(value, symbol="₹", decimals=2) -> str:
    if value is None or value == "N/A":
        return "N/A"
    try:
        return f"{symbol}{float(value):,.{decimals}f}"
    except (ValueError, TypeError):
        return "N/A"


def fmt_large_number(value, symbol="₹") -> str:
    """Formats large numbers using Indian Crore/Lakh convention where sensible."""
    if value is None or value == "N/A":
        return "N/A"
    try:
        v = float(value)
    except (ValueError, TypeError):
        return "N/A"

    abs_v = abs(v)
    if abs_v >= 1e7:
        return f"{symbol}{v / 1e7:,.2f} Cr"
    if abs_v >= 1e5:
        return f"{symbol}{v / 1e5:,.2f} L"
    return f"{symbol}{v:,.2f}"


def fmt_percent(value, decimals=2, already_fraction=False) -> str:
    """already_fraction=True means value like 0.045 -> '4.50%'."""
    if value is None or value == "N/A":
        return "N/A"
    try:
        v = float(value)
    except (ValueError, TypeError):
        return "N/A"
    if already_fraction:
        v = v * 100
    return f"{v:,.{decimals}f}%"


def fmt_number(value, decimals=2) -> str:
    if value is None or value == "N/A":
        return "N/A"
    try:
        return f"{float(value):,.{decimals}f}"
    except (ValueError, TypeError):
        return "N/A"


def fmt_change(value, decimals=2) -> str:
    if value is None or value == "N/A":
        return "N/A"
    try:
        v = float(value)
    except (ValueError, TypeError):
        return "N/A"
    sign = "+" if v >= 0 else ""
    return f"{sign}{v:,.{decimals}f}"


def color_for_change(value) -> str:
    if value is None or value == "N/A":
        return "gray"
    try:
        v = float(value)
    except (ValueError, TypeError):
        return "gray"
    if v > 0:
        return "green"
    if v < 0:
        return "red"
    return "gray"
