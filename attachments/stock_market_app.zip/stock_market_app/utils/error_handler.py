"""Centralized error handling. UI code should call `friendly_error` for
user-facing messages and `log_error` to record the technical detail."""
import logging
import sys

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger("stock_app")

GENERIC_MESSAGE = "Unable to fetch market data right now. Please try again."


def log_error(context: str, exc: Exception):
    logger.error("Error in %s: %s", context, repr(exc))


def friendly_error(context: str = "", custom_message: str | None = None) -> str:
    return custom_message or GENERIC_MESSAGE
