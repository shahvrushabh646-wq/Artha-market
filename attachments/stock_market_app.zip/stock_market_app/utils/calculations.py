"""
Core financial calculations. Kept isolated from UI code so they can be
unit tested directly (see tests/test_calculations.py).
"""
from __future__ import annotations
import pandas as pd


def pct_below_high(current_price: float, high: float):
    """((High - Current) / High) * 100"""
    if not high or high == 0 or current_price is None:
        return None
    return round(((high - current_price) / high) * 100, 2)


def pct_above_low(current_price: float, low: float):
    """((Current - Low) / Low) * 100"""
    if not low or low == 0 or current_price is None:
        return None
    return round(((current_price - low) / low) * 100, 2)


def period_high_low(history: pd.DataFrame):
    """Returns (high, high_date, low, low_date) from an OHLC DataFrame."""
    if history is None or history.empty or "High" not in history.columns:
        return None, None, None, None
    high_idx = history["High"].idxmax()
    low_idx = history["Low"].idxmin()
    high = float(history.loc[high_idx, "High"])
    low = float(history.loc[low_idx, "Low"])
    high_date = history.loc[high_idx, "Date"] if "Date" in history.columns else None
    low_date = history.loc[low_idx, "Date"] if "Date" in history.columns else None
    return round(high, 2), high_date, round(low, 2), low_date


# ---------------------------------------------------------------------------
# Custom valuation rule — DO NOT MODIFY THE LOGIC (per user specification).
# Labeled everywhere in the UI as a "User-defined valuation rule", not
# professional investment advice.
# ---------------------------------------------------------------------------
def custom_valuation(high_5y: float, current_price: float):
    if high_5y is None or current_price is None:
        return None

    price_75 = round(high_5y * 0.25, 2)
    price_85 = round(high_5y * 0.15, 2)
    price_95 = round(high_5y * 0.05, 2)

    if current_price <= price_75:
        signal = "🟢 BUY"
    else:
        signal = "🔴 WAIT"

    return {
        "high_5y": high_5y,
        "price_75": price_75,
        "price_85": price_85,
        "price_95": price_95,
        "current_price": current_price,
        "signal": signal,
    }


def optional_below_high_levels(high: float):
    """Separate from the custom rule: straightforward "% below high" levels."""
    if not high:
        return {}
    levels = {}
    for pct in (10, 20, 25, 30, 50):
        levels[f"{pct}% below high"] = round(high * (1 - pct / 100), 2)
    return levels


def stock_score(technical_summary: dict, fundamentals: dict, valuation: dict | None):
    """
    Transparent stock score out of 100:
      Technical  : 0-40  (based on bullish/bearish point balance)
      Fundamental: 0-30  (based on how many core metrics are available & healthy)
      Valuation  : 0-30  (based on the custom valuation rule)
    Missing data reduces the achievable points for that component rather
    than being replaced with a fake/default value.
    """
    breakdown = {}

    # Technical: 0-40
    b = technical_summary.get("bullish_points", 0)
    s = technical_summary.get("bearish_points", 0)
    total_pts = b + s
    if total_pts == 0:
        tech_score = 0
    else:
        tech_score = round((b / total_pts) * 40)
    breakdown["Technical Score"] = tech_score

    # Fundamental: 0-30 — reward reasonable PE, positive EPS, low D/E when available
    fund_score = 0
    fund_max = 0
    pe = fundamentals.get("Trailing P/E")
    eps = fundamentals.get("EPS")
    de = fundamentals.get("Debt/Equity")

    if pe not in (None, "N/A"):
        fund_max += 10
        try:
            fund_score += 10 if 0 < float(pe) < 35 else 4
        except (ValueError, TypeError):
            pass
    if eps not in (None, "N/A"):
        fund_max += 10
        try:
            fund_score += 10 if float(eps) > 0 else 2
        except (ValueError, TypeError):
            pass
    if de not in (None, "N/A"):
        fund_max += 10
        try:
            fund_score += 10 if float(de) < 100 else 4
        except (ValueError, TypeError):
            pass

    # Rescale whatever was actually measurable onto the 0-30 band
    fund_score_scaled = round((fund_score / fund_max) * 30) if fund_max else 0
    breakdown["Fundamental Score"] = fund_score_scaled

    # Valuation: 0-30
    val_score = 0
    if valuation:
        val_score = 30 if "BUY" in valuation.get("signal", "") else 12
    breakdown["Valuation Score"] = val_score

    total = breakdown["Technical Score"] + breakdown["Fundamental Score"] + breakdown["Valuation Score"]
    breakdown["Total Score"] = total
    return breakdown
