"""
Basic unit tests. Run with:
    python -m pytest tests/ -v
or, without pytest installed:
    python tests/test_calculations.py
"""
import sys
import os
import datetime as dt
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd

from utils.calculations import (
    pct_below_high, pct_above_low, period_high_low, custom_valuation,
    optional_below_high_levels, stock_score,
)
from utils.formatting import fmt_currency, fmt_percent, fmt_large_number


class TestPercentages(unittest.TestCase):
    def test_pct_below_high(self):
        self.assertEqual(pct_below_high(90, 100), 10.0)

    def test_pct_below_high_none_inputs(self):
        self.assertIsNone(pct_below_high(90, None))
        self.assertIsNone(pct_below_high(None, 100))

    def test_pct_above_low(self):
        self.assertEqual(pct_above_low(110, 100), 10.0)

    def test_pct_above_low_zero_low(self):
        self.assertIsNone(pct_above_low(110, 0))


class TestHighLow(unittest.TestCase):
    def test_period_high_low(self):
        df = pd.DataFrame({
            "Date": pd.date_range("2024-01-01", periods=5),
            "High": [10, 20, 15, 25, 12],
            "Low": [8, 15, 9, 20, 10],
        })
        high, high_date, low, low_date = period_high_low(df)
        self.assertEqual(high, 25)
        self.assertEqual(low, 8)

    def test_empty_df(self):
        high, high_date, low, low_date = period_high_low(pd.DataFrame())
        self.assertIsNone(high)
        self.assertIsNone(low)


class TestCustomValuationRule(unittest.TestCase):
    """Verifies the EXACT rule specified: price_75 = high*0.25, price_85 =
    high*0.15, price_95 = high*0.05, BUY if current <= price_75 else WAIT."""

    def test_buy_signal(self):
        result = custom_valuation(high_5y=1000, current_price=200)
        self.assertEqual(result["price_75"], 250.0)
        self.assertEqual(result["price_85"], 150.0)
        self.assertEqual(result["price_95"], 50.0)
        self.assertEqual(result["signal"], "🟢 BUY")

    def test_wait_signal(self):
        result = custom_valuation(high_5y=1000, current_price=300)
        self.assertEqual(result["signal"], "🔴 WAIT")

    def test_boundary_equals_buy(self):
        # current_price == price_75 exactly -> BUY (rule uses <=)
        result = custom_valuation(high_5y=1000, current_price=250)
        self.assertEqual(result["signal"], "🟢 BUY")

    def test_none_inputs(self):
        self.assertIsNone(custom_valuation(None, 100))
        self.assertIsNone(custom_valuation(1000, None))


class TestOptionalLevels(unittest.TestCase):
    def test_levels(self):
        levels = optional_below_high_levels(100)
        self.assertEqual(levels["10% below high"], 90.0)
        self.assertEqual(levels["50% below high"], 50.0)

    def test_zero_high(self):
        self.assertEqual(optional_below_high_levels(0), {})


class TestStockScore(unittest.TestCase):
    def test_score_bounds(self):
        tech = {"bullish_points": 3, "bearish_points": 1}
        fund = {"Trailing P/E": 20, "EPS": 5, "Debt/Equity": 40}
        val = {"signal": "🟢 BUY"}
        score = stock_score(tech, fund, val)
        self.assertLessEqual(score["Total Score"], 100)
        self.assertGreaterEqual(score["Total Score"], 0)

    def test_missing_data_does_not_crash(self):
        tech = {"bullish_points": 0, "bearish_points": 0}
        fund = {}
        score = stock_score(tech, fund, None)
        self.assertEqual(score["Technical Score"], 0)
        self.assertEqual(score["Valuation Score"], 0)


class TestFormatting(unittest.TestCase):
    def test_fmt_currency_none(self):
        self.assertEqual(fmt_currency(None), "N/A")

    def test_fmt_currency_value(self):
        self.assertEqual(fmt_currency(1234.5), "₹1,234.50")

    def test_fmt_percent_na(self):
        self.assertEqual(fmt_percent("N/A"), "N/A")

    def test_fmt_large_number_crore(self):
        self.assertIn("Cr", fmt_large_number(150000000))


class TestInvalidInputHandling(unittest.TestCase):
    def test_portfolio_validation_quantity(self):
        from services.portfolio_service import add_holding
        with self.assertRaises(ValueError):
            add_holding("TEST.NS", "Test", 0, 100, dt.date.today())

    def test_portfolio_validation_price(self):
        from services.portfolio_service import add_holding
        with self.assertRaises(ValueError):
            add_holding("TEST.NS", "Test", 10, 0, dt.date.today())


if __name__ == "__main__":
    unittest.main()
