"""Reusable st.metric-based card rendering helpers."""
import streamlit as st
from utils.formatting import fmt_currency, fmt_change, fmt_percent


def price_card(label: str, price, change=None, change_pct=None, currency="₹"):
    delta = None
    if change is not None and change_pct is not None:
        delta = f"{fmt_change(change)} ({fmt_change(change_pct)}%)"
    st.metric(label, fmt_currency(price, currency) if price is not None else "N/A", delta)


def stat_card(label: str, value: str):
    st.metric(label, value if value not in (None, "") else "N/A")


def index_card(name: str, value, change, change_pct, currency="₹"):
    with st.container(border=True):
        price_card(name, value, change, change_pct, currency)


def signal_badge(signal: str):
    if "BUY" in (signal or ""):
        st.success(signal)
    elif "WAIT" in (signal or ""):
        st.error(signal)
    else:
        st.info(signal or "N/A")


def verdict_badge(verdict: str):
    if "Bullish" in (verdict or ""):
        st.success(verdict)
    elif "Bearish" in (verdict or ""):
        st.error(verdict)
    else:
        st.warning(verdict or "N/A")
