"""Table rendering helpers, tuned to stay readable on narrow/mobile screens."""
import pandas as pd
import streamlit as st


def render_df(df: pd.DataFrame, use_container_width=True, hide_index=True):
    if df is None or df.empty:
        st.info("No data available.")
        return
    st.dataframe(df, use_container_width=use_container_width, hide_index=hide_index)


def render_movers_table(rows: list[dict], title: str):
    st.subheader(title)
    if not rows:
        st.info("No data available.")
        return
    df = pd.DataFrame(rows)
    st.dataframe(df, use_container_width=True, hide_index=True)


def render_key_value(pairs: dict, columns: int = 2):
    """Renders a dict as a compact two-column-on-desktop / stacked-on-mobile
    key/value list — Streamlit columns collapse to a single column on
    narrow viewports automatically."""
    items = list(pairs.items())
    cols = st.columns(columns)
    for i, (k, v) in enumerate(items):
        with cols[i % columns]:
            st.markdown(f"**{k}:** {v}")
