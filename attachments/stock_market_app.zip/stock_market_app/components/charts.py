"""Reusable Plotly chart builders."""
import pandas as pd
import plotly.graph_objects as go


def candlestick_chart(df: pd.DataFrame, title: str = ""):
    if df is None or df.empty:
        return None

    has_ohlc = all(c in df.columns for c in ["Open", "High", "Low", "Close"])
    fig = go.Figure()

    if has_ohlc:
        fig.add_trace(go.Candlestick(
            x=df["Date"], open=df["Open"], high=df["High"],
            low=df["Low"], close=df["Close"], name="Price",
            increasing_line_color="#26a69a", decreasing_line_color="#ef5350",
        ))
    else:
        fig.add_trace(go.Scatter(x=df["Date"], y=df.get("Close"), mode="lines", name="Price"))

    fig.update_layout(
        title=title, xaxis_rangeslider_visible=False,
        template="plotly_white", height=460,
        margin=dict(l=10, r=10, t=40, b=10),
        legend=dict(orientation="h", yanchor="bottom", y=1.02),
    )
    fig.update_xaxes(rangeslider_visible=False)
    return fig


def volume_chart(df: pd.DataFrame):
    if df is None or df.empty or "Volume" not in df.columns:
        return None
    colors = None
    if "Close" in df.columns and "Open" in df.columns:
        colors = ["#26a69a" if c >= o else "#ef5350" for c, o in zip(df["Close"], df["Open"])]
    fig = go.Figure(go.Bar(x=df["Date"], y=df["Volume"], marker_color=colors, name="Volume"))
    fig.update_layout(template="plotly_white", height=180,
                       margin=dict(l=10, r=10, t=10, b=10))
    return fig


def line_chart_with_sma(df: pd.DataFrame, sma20=None, sma50=None, sma200=None, title=""):
    if df is None or df.empty:
        return None
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df["Date"], y=df["Close"], name="Close", line=dict(color="#1f77b4")))
    if sma20 is not None:
        fig.add_trace(go.Scatter(x=df["Date"], y=sma20, name="SMA 20", line=dict(width=1, color="orange")))
    if sma50 is not None:
        fig.add_trace(go.Scatter(x=df["Date"], y=sma50, name="SMA 50", line=dict(width=1, color="green")))
    if sma200 is not None:
        fig.add_trace(go.Scatter(x=df["Date"], y=sma200, name="SMA 200", line=dict(width=1, color="purple")))
    fig.update_layout(title=title, template="plotly_white", height=420,
                       margin=dict(l=10, r=10, t=40, b=10),
                       legend=dict(orientation="h", yanchor="bottom", y=1.02))
    return fig


def rsi_chart(df: pd.DataFrame, rsi_series):
    if df is None or df.empty or rsi_series is None or rsi_series.empty:
        return None
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df["Date"], y=rsi_series, name="RSI 14", line=dict(color="#8e44ad")))
    fig.add_hline(y=70, line_dash="dash", line_color="red", opacity=0.5)
    fig.add_hline(y=30, line_dash="dash", line_color="green", opacity=0.5)
    fig.update_layout(template="plotly_white", height=220,
                       margin=dict(l=10, r=10, t=10, b=10), yaxis_range=[0, 100])
    return fig


def allocation_pie(labels, values, title="Portfolio Allocation"):
    if not labels or not values:
        return None
    fig = go.Figure(go.Pie(labels=labels, values=values, hole=0.45))
    fig.update_layout(title=title, template="plotly_white", height=380,
                       margin=dict(l=10, r=10, t=40, b=10))
    return fig
