"""Shared sidebar: app branding, navigation, quick search, refresh, about."""
import streamlit as st

from config import APP_NAME, APP_SUBTITLE, DISCLAIMER
from data.market_data import normalize_symbol

PAGES = ["Dashboard", "Stock Analysis", "Portfolio", "Watchlist", "Alerts", "Settings", "About"]


def render_sidebar() -> str:
    with st.sidebar:
        st.markdown(f"## 📈 {APP_NAME}")
        st.caption(APP_SUBTITLE)
        st.divider()

        st.markdown("### 🔎 Quick Stock Search")
        search_val = st.text_input(
            "Enter NSE/BSE Stock Symbol",
            placeholder="e.g. RELIANCE, TCS, INFY.NS",
            key="sidebar_search",
        )
        if st.button("Go to Analysis", use_container_width=True) and search_val:
            st.session_state["selected_symbol"] = normalize_symbol(search_val)
            st.session_state["nav_page"] = "Stock Analysis"
            st.rerun()

        st.divider()
        st.markdown("### 📂 Navigation")
        current = st.session_state.get("nav_page", "Dashboard")
        page = st.radio("Navigate", PAGES, index=PAGES.index(current) if current in PAGES else 0,
                         label_visibility="collapsed")
        st.session_state["nav_page"] = page

        st.divider()
        if st.button("🔄 Refresh Data", use_container_width=True):
            st.cache_data.clear()
            st.rerun()

        st.divider()
        with st.expander("ℹ️ About"):
            st.caption(DISCLAIMER)

    return page
